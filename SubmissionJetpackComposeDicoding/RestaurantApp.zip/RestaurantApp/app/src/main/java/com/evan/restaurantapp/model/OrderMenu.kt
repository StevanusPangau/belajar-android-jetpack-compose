package com.evan.restaurantapp.model

data class OrderMenu(
    val menu: Menu,
    val count: Int
)